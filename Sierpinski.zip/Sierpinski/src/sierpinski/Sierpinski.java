package sierpinski;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Sierpinski extends JPanel implements Runnable{

    public JPanel panel=new JPanel();
    public JFrame frame=new JFrame("Sierpinski triangle");
    public Thread thread;
    
    static public int st=0;
    static public int sierpinski=0;
    
    public void run() {
     while(true){
        try{
            Triangle.list=new ArrayList<Triangle>();
            sierpinski++;
            new Triangle(new Point(10,40),300);
            makeTriangle(sierpinski);
            
            this.repaint();
            Thread.sleep(25);
     }catch(Exception exc){}
     }
    }
    
    public void makeTriangle(int z)
    {
        int c=0;
        try{
        for(int q=0;q<Triangle.list.size();q++)
        {
        c++;
        if(c<z){
        Triangle t=Triangle.list.get(q);
        new Triangle(t.pa,t.a2);
        new Triangle(t.pb,t.a2);
        new Triangle(t.pc,t.a2);
        }
        }
        }catch(Exception exc){};
    }
    
     public static void main(String[] args) {
        Sierpinski r=new Sierpinski();
        r.panel = r;
        r.frame = new JFrame("Sierpinski triangle");
        r.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        r.frame.getContentPane().add(r.panel);
        r.panel.setSize(300, 300);
        r.frame.setLocation(500, 300);
        r.frame.pack();
        r.frame.show();
        r.thread=new Thread(r);
        r.thread.start();
        new Triangle(new Point(10,40),300);
    }
     
    public Dimension getPreferredSize(){
        return new Dimension(640, 480);
    }
    
    public void paintComponent(Graphics g){
    	super.paintComponent(g);
        g.setColor(Color.white);
        g.fillRect(0, 0, 640, 480);
        g.setColor(Color.blue);
        for(Triangle t:Triangle.list)
            {
            Point a=t.p1;
            Point b=t.p2;
            Point c=t.p3;
            g.drawLine((int)a.px,(int)a.py,(int)b.px,(int)b.py);
            g.drawLine((int)a.px,(int)a.py,(int)c.px,(int)c.py);
            g.drawLine((int)b.px,(int)b.py,(int)c.px,(int)c.py);
            }
     }
    
}
