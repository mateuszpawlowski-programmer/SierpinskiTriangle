package sierpinski;

public class Point {
    public float px;
    public float py;

    Point(float x,float y)
    {
    px=x;
    py=y;
    }
}
