package sierpinski;

import java.util.ArrayList;

public class Triangle {
    
    public Point p1;
    public Point p2;
    public Point p3;
    
    public Point pa;
    public Point pb;
    public Point pc;
    
    public float a;
    public float a2;
    
    public static int tcount=0;
    public static ArrayList<Triangle> list=new ArrayList<Triangle>();
    
    Triangle(Point pk1,float ak)
    {
            a=ak;
            Point pk2=new Point(pk1.px+a,pk1.py);
            Point pk3=new Point(pk1.px,pk1.py+a);
            p1=new Point(pk1.px,pk1.py);
            p2=new Point(pk2.px,pk2.py);
            p3=new Point(pk3.px,pk3.py);

            list.add(this);

            a2=a/2;
            pa=new Point(p1.px,p1.py);
            pb=new Point(p1.px+a2,p1.py);
            pc=new Point(p1.px,p1.py+a2);
    }
}
